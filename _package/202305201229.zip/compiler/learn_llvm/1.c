#include <stdio.h>

// clang -emit-llvm test.cpp -S -o test.ll

int fun(int x)
{
    if (x > 0) return x*fun(x);
    return 1;
}


int if_def(int a, int b)
{
    int ret;
    int c = -100, e = -1000;

    if (a > 0 || b == 2) {
        int c = b*a;
        int d = c*5;
        ret = c+d;
    }
    else {
        int e = b/a;
        ret = e*2;
    }

    return ret;
}

int main()
{
    int ans;
    ans = if_def(-10, 2);

    printf("%d\n", ans);

    return 0;
}