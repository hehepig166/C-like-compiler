#include "UTILS.h"

#include <bits/stdc++.h>
using namespace std;

void logError(const char *str, std::pair<int, int> pos) {
    std::cerr <<"[Lexer] err (" <<pos.first <<", " <<pos.second <<") " <<str <<std::endl;
    exit(0);
}

void logError(const char *pre, const char *str, std::pair<int, int> pos) {
    cerr <<pre <<" err (" <<pos.first <<", " <<pos.second <<") " <<str <<endl;
    exit(0);
}