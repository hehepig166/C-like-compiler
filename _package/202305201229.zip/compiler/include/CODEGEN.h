#ifndef __HEHEPIG_CODEGEN_H__
#define __HEHEPIG_CODEGEN_H__

#include <vector>
#include <map>
#include <string>
#include <iostream>

typedef std::string                     VarType;
typedef std::pair<int, VarType>         VarInfo;
typedef std::map<std::string, VarInfo>  NameMap;



struct Code {
    int res;
    std::string op;
    int v1;
    int v2;

    Code(int res_, std::string op_, int v1_, int v2_): res(res_), op(op_), v1(v1_), v2(v2_) {}

    friend std::ostream& operator<<(std::ostream &fout, const Code &c) {
        fout <<"%" <<c.res <<" = " <<c.op;
        if (c.v1 >= 0) {
            fout <<" %" <<c.v1;
            if (c.v2 >= 0) fout <<" %" <<c.v2;
        }
        return fout;
    }
};

class Function {
public:
    int cnt;
    std::vector<VarInfo>    variables;
    std::vector<NameMap>    envs;

    std::vector<Code>       codes;

public:

    Function(): cnt(0), envs(1) {}

    //====================================================
    // 符号处理相关
    //====================================================
    void env_push();
    void env_pop();

    int new_var(std::string varName, VarType varType);
    int new_temp();

    VarInfo* get_var(std::string varName);

    //====================================================
    // 代码处理相关
    //====================================================
    int new_code(int res, std::string op, int v1, int v2);

    Code& get_code(int index);

};





#endif