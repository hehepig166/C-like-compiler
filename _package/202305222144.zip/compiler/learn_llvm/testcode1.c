
int test_while()
{
    int a;
    a = 10;
    while (a > 0) {
        a = a-1;
    }
}

int test_if()
{
    int a, b, c;
    if (a > 0) {
        c = 2;
    }
    else {
        int d;
        c = d;
    }
}

int main1(int a, int b)
{
    int x, c;
    x = a-2*(a+b)+c;
}